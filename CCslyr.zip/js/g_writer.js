
// g_writer.js — Google DMCA フォーム自動入力 (radio final fix)
chrome.storage.local.get(function (items) {
  const mode = items.m_mode;
  const urls = items['m_Arr' + mode] || [];
  if (!urls.length) { alert('未報告URLがありません'); return; }
  const fullname = (items.m_family || '') + ' ' + (items.m_name || '');

  function manual(el, val) {
    if (!el) return;
    el.value = val;
    ['input', 'change'].forEach(ev => el.dispatchEvent(new Event(ev, { bubbles: true })));
  }

  function tickCheckboxes() {
    document.querySelectorAll('material-checkbox[role="checkbox"]').forEach(cb => {
      if (cb.getAttribute('aria-checked') !== 'true') { cb.click(); }
    });
  }

  function clickRadioElem(elem) {
    if (!elem) return;
    elem.click();
    if (elem.getAttribute('aria-checked') === 'true') return true;
    const icon = elem.querySelector('.icon-container');
    if (icon) { icon.click(); if (elem.getAttribute('aria-checked') === 'true') return true; }
    elem.focus();
    ['keydown', 'keyup'].forEach(e => {
      const ev = new KeyboardEvent(e, { key: ' ', code: 'Space', bubbles: true });
      elem.dispatchEvent(ev);
    });
    return elem.getAttribute('aria-checked') === 'true';
  }

  // returns true if successfully selected
  function selectRadioNo() {
    const mats = Array.from(document.querySelectorAll('material-radio[role="radio"]'));
    for (const r of mats) {
      const txt = (r.querySelector('.content') || {}).textContent || '';
      if (/いいえ|No/i.test(txt)) {
        if (r.getAttribute('aria-checked') === 'true') return true;
        if (clickRadioElem(r)) return true;
      }
    }
    // fallback traditional radio
    const inputs = Array.from(document.querySelectorAll('input[type="radio"]'));
    for (const inp of inputs) {
      const lbl = inp.nextElementSibling ? inp.nextElementSibling.textContent : '';
      if (inp.value === 'no' || /いいえ|No/i.test(lbl)) {
        if (inp.checked) return true;
        inp.click();
        inp.checked = true;
        ['input', 'change'].forEach(ev => inp.dispatchEvent(new Event(ev, { bubbles: true })));
        return inp.checked;
      }
    }
    return false;
  }

  async function ensureRadioNo() {
    for (let i = 0; i < 40; i++) {           // 最大8秒
      if (selectRadioNo()) return;
      await new Promise(r => setTimeout(r, 200));
    }
  }

  function attachSubmit() {
    const btn = document.querySelector('[data-test-id="submit-button"], [type="submit"]');
    if (!btn || btn.dataset.bound) return;
    btn.dataset.bound = 1;
    btn.addEventListener('click', () => chrome.storage.local.get(null, cur => {
      const m = cur.m_mode;
      const arr = cur['m_Arr' + m] || [];
      if (!arr.length) return;
      const now = new Date().toLocaleString();
      chrome.storage.local.set({
        ['m_Arr' + m]: [],
        ['m_DateArr' + m]: [],
        ['m_FinArr' + m]: (cur['m_FinArr' + m] || []).concat(arr),
        ['m_FinDateArr' + m]: (cur['m_FinDateArr' + m] || []).concat(arr.map(() => now))
      });
    }));
  }

  function scrollBottom() { setTimeout(() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' }), 400); }

  async function fill() {
    const sig = document.querySelector('input[aria-label="署名"]'); if (!sig) return false;

    manual(document.querySelector('input[aria-label="名"]'), items.m_name);
    manual(document.querySelector('input[aria-label="姓"]'), items.m_family);
    manual(document.querySelector('input[aria-label="組織名"]'), items.m_company);
    manual(document.querySelector('input[type="email"]'), items.m_email);
    manual(sig, fullname);

    const ta = document.querySelectorAll('textarea');
    if (ta[0]) manual(ta[0], items['m_original' + mode]);
    if (ta[1]) manual(ta[1], items['m_infringement' + mode]);
    if (ta[2]) manual(ta[2], urls.join('\n'));

    tickCheckboxes();
    await ensureRadioNo();
    attachSubmit();
    scrollBottom();
    return true;
  }

  function init() {
    fill().then(done => {
      if (done) return;
      const obs = new MutationObserver(() => fill().then(ok => { if (ok) obs.disconnect(); }));
      obs.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => obs.disconnect(), 15000);
    });
  }

  document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', init) : init();
  
});
